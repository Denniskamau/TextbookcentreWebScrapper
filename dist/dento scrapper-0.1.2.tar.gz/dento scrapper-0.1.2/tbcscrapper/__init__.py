from . import bookscrapper
from . import textbookcentreGUI

__version__ = "0.1.2"